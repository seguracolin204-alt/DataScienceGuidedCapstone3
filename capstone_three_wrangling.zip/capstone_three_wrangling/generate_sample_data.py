"""
Generate a schema-faithful synthetic version of the UCI Bank Marketing dataset.

The real file is bank-additional-full.csv (41,188 rows × 21 columns), released
alongside the Moro, Cortez & Rita (2014) paper. This synthetic version mirrors:
  - The full column schema and dtypes
  - Realistic value ranges and category vocabularies
  - Real-world data issues you'd have to handle in the wrangling step:
      * 'unknown' sentinel values in categorical columns
      * pdays == 999 encoding for "never previously contacted"
      * duration column that perfectly leaks the outcome
      * mild class imbalance (~11% positives)
      * a handful of exact duplicate rows from source-system re-exports
"""

import numpy as np
import pandas as pd
from pathlib import Path

OUT_PATH = Path("/home/claude/c3_wrangling/bank-additional-full.csv")

N_ROWS = 41188  # match the real dataset size
rng = np.random.default_rng(42)

# --- vocabularies matching the real dataset ---
job_cats = ["admin.", "blue-collar", "entrepreneur", "housemaid", "management",
            "retired", "self-employed", "services", "student", "technician",
            "unemployed", "unknown"]
marital_cats = ["divorced", "married", "single", "unknown"]
education_cats = ["basic.4y", "basic.6y", "basic.9y", "high.school", "illiterate",
                  "professional.course", "university.degree", "unknown"]
yesno_unknown = ["no", "yes", "unknown"]
contact_cats = ["cellular", "telephone"]
month_cats = ["mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"]
day_cats = ["mon", "tue", "wed", "thu", "fri"]
poutcome_cats = ["failure", "nonexistent", "success"]

# --- generate columns ---
data = {}

# age: right-skewed 17-98, mode around 35-45
data["age"] = rng.integers(17, 99, N_ROWS)

# job: skewed toward admin/blue-collar/technician; unknown ~0.8%
job_probs = [0.253, 0.224, 0.036, 0.026, 0.070, 0.042, 0.035,
             0.096, 0.021, 0.164, 0.025, 0.008]
data["job"] = rng.choice(job_cats, N_ROWS, p=job_probs)

# marital: mostly married; unknown ~0.2%
data["marital"] = rng.choice(marital_cats, N_ROWS, p=[0.112, 0.606, 0.28, 0.002])

# education: unknown ~4%
edu_probs = [0.101, 0.055, 0.146, 0.231, 0.0005, 0.128, 0.295, 0.0435]
data["education"] = rng.choice(education_cats, N_ROWS, p=edu_probs)

# default (has credit in default?): mostly no, unknown ~20% (real dataset quirk!)
data["default"] = rng.choice(yesno_unknown, N_ROWS, p=[0.7909, 0.0001, 0.209])

# housing loan: roughly even yes/no, unknown ~2.4%
data["housing"] = rng.choice(yesno_unknown, N_ROWS, p=[0.452, 0.524, 0.024])

# personal loan: mostly no, unknown ~2.4%
data["loan"] = rng.choice(yesno_unknown, N_ROWS, p=[0.824, 0.152, 0.024])

# contact: cellular vs telephone (roughly 63/37)
data["contact"] = rng.choice(contact_cats, N_ROWS, p=[0.635, 0.365])

# month: heavily skewed to may
month_probs = [0.013, 0.064, 0.334, 0.129, 0.174, 0.150, 0.014, 0.017, 0.101, 0.004]
data["month"] = rng.choice(month_cats, N_ROWS, p=month_probs)

# day_of_week: roughly uniform
data["day_of_week"] = rng.choice(day_cats, N_ROWS, p=[0.207, 0.196, 0.198, 0.204, 0.195])

# duration: right-skewed 0-4918. This is the leaky feature.
# Most are 100-400s; a few are very long. The zero-duration cases are ALL 'no'.
duration = np.abs(rng.exponential(scale=220, size=N_ROWS)).astype(int)
duration = np.clip(duration, 0, 4918)
# inject a small number of exact zeros
zero_idx = rng.choice(N_ROWS, size=4, replace=False)
duration[zero_idx] = 0
data["duration"] = duration

# campaign: number of contacts during this campaign. 1-56, heavily skewed to 1-3.
camp = rng.geometric(p=0.35, size=N_ROWS)
camp = np.clip(camp, 1, 56)
data["campaign"] = camp

# pdays: 999 means never previously contacted (about 96%). Otherwise 0-27.
pdays = np.full(N_ROWS, 999)
recontact_mask = rng.random(N_ROWS) < 0.037
pdays[recontact_mask] = rng.integers(0, 28, recontact_mask.sum())
data["pdays"] = pdays

# previous: number of prior campaign contacts, mostly 0
prev = np.where(pdays == 999, 0, rng.integers(1, 8, N_ROWS))
data["previous"] = prev

# poutcome: nonexistent when pdays==999, otherwise failure/success
poutcome = np.where(pdays == 999, "nonexistent",
                    rng.choice(["failure", "success"], N_ROWS, p=[0.66, 0.34]))
data["poutcome"] = poutcome

# social/economic context (roughly matches real ranges)
data["emp.var.rate"] = np.round(rng.uniform(-3.4, 1.4, N_ROWS), 1)
data["cons.price.idx"] = np.round(rng.uniform(92.201, 94.767, N_ROWS), 3)
data["cons.conf.idx"] = np.round(rng.uniform(-50.8, -26.9, N_ROWS), 1)
data["euribor3m"] = np.round(rng.uniform(0.634, 5.045, N_ROWS), 3)
data["nr.employed"] = np.round(rng.uniform(4963.6, 5228.1, N_ROWS), 1)

# --- target: y (yes/no). Base rate ~11%. Longer duration = higher yes rate (natural). ---
# We give duration a small positive lift on p(yes) so the leakage is visible in EDA
base_p = 0.11
dur_lift = np.clip((duration - 200) / 4000, -0.05, 0.6)
p_yes = np.clip(base_p + dur_lift, 0.02, 0.95)
# zero-duration cases must be no (matches real dataset)
p_yes[duration == 0] = 0
y = np.where(rng.random(N_ROWS) < p_yes, "yes", "no")
data["y"] = y

df = pd.DataFrame(data)

# --- inject exact duplicates (source-system re-exports) ---
dupes = df.sample(23, random_state=1)
df = pd.concat([df, dupes], ignore_index=True)

# Shuffle rows so duplicates are not obviously at the end
df = df.sample(frac=1, random_state=2).reset_index(drop=True)

df.to_csv(OUT_PATH, index=False, sep=";")  # real file uses semicolons
print(f"Wrote {OUT_PATH}: {df.shape}")
print(f"  Positive class rate: {(df['y'] == 'yes').mean():.3f}")
print(f"  Duplicate rows: {df.duplicated().sum()}")
print(f"  Columns with 'unknown' values:")
for col in ["job", "marital", "education", "default", "housing", "loan"]:
    n = (df[col] == "unknown").sum()
    print(f"    {col}: {n} ({100*n/len(df):.1f}%)")
print(f"  pdays == 999 count: {(df['pdays'] == 999).sum()}")
