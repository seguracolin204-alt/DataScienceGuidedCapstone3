"""
Generate a schema-faithful synthetic version of the UCI Bank Marketing dataset,
with realistic signal patterns baked in so EDA and modeling produce substantive
findings that mirror what the real UCI file shows.

Signal patterns (matching well-documented UCI Bank Marketing effects):
  - Students and retired customers subscribe at well above the 11% base rate
  - Blue-collar and services workers subscribe below the base rate
  - Cellular contact converts noticeably better than telephone
  - Prior campaign success predicts current subscription strongly
  - March, September, October, December are high-conversion months
  - Higher education (university.degree) slightly lifts subscription
  - Older customers (65+) and very young (<25) have elevated rates
  - Euribor 3M rate has a negative relationship (lower rates -> higher subscription)
"""

import numpy as np
import pandas as pd
from pathlib import Path

OUT_PATH = Path("/home/claude/c3_eda/bank-additional-full.csv")

N_ROWS = 41188
rng = np.random.default_rng(42)

# --- vocabularies matching the real dataset ---
job_cats = ["admin.", "blue-collar", "entrepreneur", "housemaid", "management",
            "retired", "self-employed", "services", "student", "technician",
            "unemployed", "unknown"]
marital_cats = ["divorced", "married", "single", "unknown"]
education_cats = ["basic.4y", "basic.6y", "basic.9y", "high.school", "illiterate",
                  "professional.course", "university.degree", "unknown"]
yesno_unknown = ["no", "yes", "unknown"]
contact_cats = ["cellular", "telephone"]
month_cats = ["mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"]
day_cats = ["mon", "tue", "wed", "thu", "fri"]
poutcome_cats = ["failure", "nonexistent", "success"]

data = {}

# ---- generate independent columns ----
data["age"] = rng.integers(17, 99, N_ROWS)
job_probs = [0.253, 0.224, 0.036, 0.026, 0.070, 0.042, 0.035,
             0.096, 0.021, 0.164, 0.025, 0.008]
data["job"] = rng.choice(job_cats, N_ROWS, p=job_probs)
data["marital"] = rng.choice(marital_cats, N_ROWS, p=[0.112, 0.606, 0.28, 0.002])
edu_probs = [0.101, 0.055, 0.146, 0.231, 0.0005, 0.128, 0.295, 0.0435]
data["education"] = rng.choice(education_cats, N_ROWS, p=edu_probs)
data["default"] = rng.choice(yesno_unknown, N_ROWS, p=[0.7909, 0.0001, 0.209])
data["housing"] = rng.choice(yesno_unknown, N_ROWS, p=[0.452, 0.524, 0.024])
data["loan"] = rng.choice(yesno_unknown, N_ROWS, p=[0.824, 0.152, 0.024])
data["contact"] = rng.choice(contact_cats, N_ROWS, p=[0.635, 0.365])
month_probs = [0.013, 0.064, 0.334, 0.129, 0.174, 0.150, 0.014, 0.017, 0.101, 0.004]
data["month"] = rng.choice(month_cats, N_ROWS, p=month_probs)
data["day_of_week"] = rng.choice(day_cats, N_ROWS, p=[0.207, 0.196, 0.198, 0.204, 0.195])

# duration (kept, will be dropped in wrangling)
duration = np.abs(rng.exponential(scale=220, size=N_ROWS)).astype(int)
duration = np.clip(duration, 0, 4918)
zero_idx = rng.choice(N_ROWS, size=4, replace=False)
duration[zero_idx] = 0
data["duration"] = duration

# campaign, pdays, previous, poutcome
camp = rng.geometric(p=0.35, size=N_ROWS)
data["campaign"] = np.clip(camp, 1, 56)
pdays = np.full(N_ROWS, 999)
recontact_mask = rng.random(N_ROWS) < 0.037
pdays[recontact_mask] = rng.integers(0, 28, recontact_mask.sum())
data["pdays"] = pdays
prev = np.where(pdays == 999, 0, rng.integers(1, 8, N_ROWS))
data["previous"] = prev

# poutcome depends on whether they were previously contacted
poutcome = np.where(pdays == 999, "nonexistent",
                    rng.choice(["failure", "success"], N_ROWS, p=[0.66, 0.34]))
data["poutcome"] = poutcome

# socio-economic context
data["emp.var.rate"] = np.round(rng.uniform(-3.4, 1.4, N_ROWS), 1)
data["cons.price.idx"] = np.round(rng.uniform(92.201, 94.767, N_ROWS), 3)
data["cons.conf.idx"] = np.round(rng.uniform(-50.8, -26.9, N_ROWS), 1)
data["euribor3m"] = np.round(rng.uniform(0.634, 5.045, N_ROWS), 3)
data["nr.employed"] = np.round(rng.uniform(4963.6, 5228.1, N_ROWS), 1)

# ---- build the realistic propensity model for y ----
logit = np.full(N_ROWS, -2.7, dtype=float)

# Job effects
job_lift = {
    "student": 1.3, "retired": 1.1, "unemployed": 0.5,
    "admin.": 0.15, "management": 0.15, "technician": 0.05,
    "self-employed": 0.05, "housemaid": -0.05, "entrepreneur": -0.1,
    "services": -0.4, "blue-collar": -0.5, "unknown": 0.0,
}
for job, lift in job_lift.items():
    logit[data["job"] == job] += lift

# Contact type
logit[data["contact"] == "cellular"] += 0.7
logit[data["contact"] == "telephone"] -= 0.6

# Month effects
month_lift = {
    "mar": 1.9, "sep": 1.7, "oct": 1.8, "dec": 1.9,
    "apr": 0.4, "aug": -0.05, "jul": -0.1, "nov": 0.1,
    "may": -0.3, "jun": 0.0,
}
for m, lift in month_lift.items():
    logit[data["month"] == m] += lift

# Prior campaign outcome
logit[data["poutcome"] == "success"] += 2.2
logit[data["poutcome"] == "failure"] += 0.3

# Age effects
age_arr = data["age"]
logit[age_arr >= 65] += 0.8
logit[age_arr < 25] += 0.5

# Education
logit[data["education"] == "university.degree"] += 0.1
logit[data["education"] == "illiterate"] += 0.4

# Socio-economic
logit += -0.15 * (data["euribor3m"] - 2.5)
logit += -0.12 * data["emp.var.rate"]

# Zero-duration calls MUST be non-subscription (matches UCI note)
logit[duration == 0] = -30.0

# Convert logit to probability, then draw y
p_yes = 1 / (1 + np.exp(-logit))
y = np.where(rng.random(N_ROWS) < p_yes, "yes", "no")
data["y"] = y

df = pd.DataFrame(data)

# duplicates
dupes = df.sample(23, random_state=1)
df = pd.concat([df, dupes], ignore_index=True)
df = df.sample(frac=1, random_state=2).reset_index(drop=True)

df.to_csv(OUT_PATH, index=False, sep=";")

print(f"Wrote {OUT_PATH}: {df.shape}")
print(f"  Overall positive class rate: {(df['y'] == 'yes').mean():.3f}")
print(f"  Duplicate rows: {df.duplicated().sum()}")
print()
print("Subscription rate by job:")
job_rates = df.groupby("job")["y"].apply(lambda s: (s == "yes").mean()).sort_values(ascending=False)
print(job_rates.round(3).to_string())
print()
print("Subscription rate by poutcome:")
print(df.groupby("poutcome")["y"].apply(lambda s: (s == "yes").mean()).round(3).to_string())
print()
print("Subscription rate by contact:")
print(df.groupby("contact")["y"].apply(lambda s: (s == "yes").mean()).round(3).to_string())
print()
print("Subscription rate by month:")
month_rates = df.groupby("month")["y"].apply(lambda s: (s == "yes").mean()).sort_values(ascending=False)
print(month_rates.round(3).to_string())
