# Capstone Three — Pre-processing + Modeling

Springboard Data Science Career Track — Business Insights Specialization
Colin Segura — Optimizing Term Deposit Marketing Campaigns for a European Bank

## How to run

1. Put all files in this folder into the same directory on your machine.
2. Open a terminal in that directory and start Jupyter: `jupyter notebook`
3. Run the notebooks in order:
   - `01_data_wrangling.ipynb` — Step 2
   - `02_eda.ipynb` — Step 3
   - `03_preprocessing_modeling.ipynb` — Steps 4 and 5 combined

## Files

- `01_data_wrangling.ipynb` — wrangling (Step 2)
- `02_eda.ipynb` — exploratory data analysis (Step 3)
- `03_preprocessing_modeling.ipynb` — preprocessing + modeling (Steps 4 and 5)
- `bank-additional-full.csv` — raw input (schema-faithful synthetic sample)
- `bank_marketing_cleaned.csv` — from Step 2, input to Step 3 and Step 4
- `X_train_scaled.csv`, `X_test_scaled.csv` — from Step 4
- `y_train.csv`, `y_test.csv` — from Step 4
- `scaler.joblib` — fitted StandardScaler from Step 4
- `final_model.joblib` — serialized final model + metadata from Step 5
- `generate_sample_data.py` — reproduces sample raw CSV
- `README.md` — this file

## Modeling results summary

| Model | CV ROC AUC | Notes |
|---|---|---|
| Baseline: Majority Class | 0.500 | Mathematical floor |
| Baseline: Rule-Based | 0.524 | 3-feature rule from EDA (cellular + hot months + hot jobs) |
| Logistic Regression (C=0.01, balanced) | 0.739 | Interpretable baseline |
| Random Forest (tuned) | 0.738 | max_depth=8, n_estimators=200 |
| **Gradient Boosting (tuned)** | **0.745** | **Selected — max_depth=3, n_estimators=200, lr=0.1** |

**Held-out test set:** ROC AUC = 0.740, PR AUC = 0.381

**Precision at top-k:**
- Top 5%: 54% precision, 3.4× lift over random
- Top 10%: 45% precision, 2.8× lift
- Top 20%: 36% precision, 2.3× lift

**Optimal threshold at $8/call, $80/subscription:** 0.09, yielding $49,280 expected profit vs $38,416 for call-everyone (28% lift, $10,864).

Top features driving predictions:
1. contact_telephone (negative — cellular is better)
2. age (U-shape captured by trees)
3. month_oct, month_mar, month_dec, month_sep (seasonal spikes)
4. poutcome_success (strongest small-segment signal)
5. euribor3m and emp.var.rate (macroeconomic context)

## Real data source

To run on the real UCI Bank Marketing dataset, download from
https://archive.ics.uci.edu/dataset/222/bank+marketing and replace
`bank-additional-full.csv`. All notebooks run unchanged.
